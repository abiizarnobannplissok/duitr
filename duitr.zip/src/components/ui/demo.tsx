
// This is file with demos of your component
// Each export is one usecase for your component

import { Component } from "@/components/ui/spotlight-button";

const DemoOne = () => {
  return <Component />;
};

export { DemoOne };
